const { Client, Databases, Query } = require('node-appwrite');// AppWrite Cloud Function v5: player-registry// functions/appwrite/src/player-registry.js



/**// Manages master player registration and heartbeatsconst { Client, Databases, Query } = require('appwrite');

 * Player Registry - Cloud Functions v5

 * Manages master player registration and heartbeats

 */

module.exports = async ({ req, res, log, error }) => {const { Client, Databases, Query } = require('node-appwrite');/**

  const client = new Client()

    .setEndpoint(process.env.APPWRITE_ENDPOINT) * Register a master player for a venue

    .setProject(process.env.APPWRITE_PROJECT_ID)

    .setKey(process.env.APPWRITE_API_KEY);/** */



  const databases = new Databases(client); * Main handler for AppWrite Cloud Functionexports.registerMasterPlayer = async ({ venueId, deviceId, userAgent }) => {



  try { */  const client = new Client()

    const body = req.bodyJson || JSON.parse(req.body || '{}');

    const { action, venueId, deviceId, userAgent } = body;module.exports = async ({ req, res, log, error }) => {    .setEndpoint(process.env.APPWRITE_ENDPOINT)



    log(`Player-registry: action=${action}, venueId=${venueId}, deviceId=${deviceId}`);  try {    .setProject(process.env.APPWRITE_PROJECT_ID)



    // Action: register - Register as master player    // Parse request    .setKey(process.env.APPWRITE_API_KEY);

    if (action === 'register') {

      if (!venueId || !deviceId || !userAgent) {    const body = req.bodyJson || JSON.parse(req.body || '{}');

        return res.json(

          { success: false, error: 'Missing required fields' },    const { action, venueId, deviceId, userAgent } = body;  const databases = new Databases(client);

          400

        );

      }

    log(`Player-registry: action=${action}, venueId=${venueId}`);  try {

      // Cleanup expired players first

      const now = Date.now();    // Cleanup expired players first

      try {

        const expired = await databases.listDocuments(    // Initialize AppWrite    await cleanupExpiredPlayers(databases);

          process.env.APPWRITE_DATABASE_ID,

          'players',    const client = new Client()

          [Query.lessThan('expiresAt', now)]

        );      .setEndpoint(process.env.APPWRITE_ENDPOINT)    // Check for existing active master



        for (const player of expired.documents) {      .setProject(process.env.APPWRITE_PROJECT_ID)    const existingMaster = await databases.listDocuments(

          await databases.deleteDocument(

            process.env.APPWRITE_DATABASE_ID,      .setKey(process.env.APPWRITE_API_KEY);      process.env.APPWRITE_DATABASE_ID,

            'players',

            player.$id      'players',

          );

        }    const databases = new Databases(client);      [Query.equal('venueId', venueId), Query.equal('status', 'active')]

        log(`Cleaned up ${expired.documents.length} expired players`);

      } catch (cleanupError) {    );

        log('Cleanup warning: ' + cleanupError.message);

      }    // Helper function to cleanup expired players



      // Check for existing active master    const cleanupExpired = async () => {    if (existingMaster.documents.length > 0) {

      const existing = await databases.listDocuments(

        process.env.APPWRITE_DATABASE_ID,      const now = Date.now();      const currentMaster = existingMaster.documents[0];

        'players',

        [      const expired = await databases.listDocuments(

          Query.equal('venueId', [venueId]),

          Query.equal('status', ['active'])        process.env.APPWRITE_DATABASE_ID,      // If same device, reconnect

        ]

      );        'players',      if (currentMaster.deviceId === deviceId) {



      if (existing.documents.length > 0) {        [Query.lessThan('expiresAt', now)]        await databases.updateDocument(

        const current = existing.documents[0];

      );          process.env.APPWRITE_DATABASE_ID,

        // Same device? Reconnect

        if (current.deviceId === deviceId) {          'players',

          await databases.updateDocument(

            process.env.APPWRITE_DATABASE_ID,      for (const player of expired.documents) {          currentMaster.$id,

            'players',

            current.$id,        await databases.deleteDocument(          {

            {

              lastHeartbeat: now,          process.env.APPWRITE_DATABASE_ID,            lastHeartbeat: Date.now(),

              expiresAt: now + 2 * 60 * 1000 // 2 minutes

            }          'players',            expiresAt: Date.now() + 24 * 60 * 60 * 1000,

          );

          player.$id          }

          log(`Device reconnected: ${deviceId}`);

          return res.json({        );        );

            success: true,

            isMaster: true,      }        return {

            playerId: current.$id,

            status: 'reconnected'      log(`Cleaned up ${expired.documents.length} expired players`);          status: 'reconnected',

          });

        }    };          playerId: currentMaster.$id,



        // Different device and still active? Conflict          currentMaster: {

        if (current.lastHeartbeat > now - 2 * 60 * 1000) {

          log(`Master conflict: ${current.deviceId} still active`);    // Register master player            deviceId: currentMaster.deviceId,

          return res.json({

            success: false,    if (action === 'register') {            lastHeartbeat: currentMaster.lastHeartbeat,

            isMaster: false,

            reason: 'MASTER_ACTIVE',      await cleanupExpired();          },

            currentMaster: {

              deviceId: current.deviceId,        };

              lastHeartbeat: current.lastHeartbeat

            }      // Check for existing active master      }

          });

        }      const existing = await databases.listDocuments(



        // Old master expired, mark as offline        process.env.APPWRITE_DATABASE_ID,      // Check if master is still active (last heartbeat < 2 minutes)

        await databases.updateDocument(

          process.env.APPWRITE_DATABASE_ID,        'players',      if (Date.now() - currentMaster.lastHeartbeat < 120000) {

          'players',

          current.$id,        [Query.equal('venueId', venueId), Query.equal('status', 'active')]        return {

          { status: 'offline', expiresAt: now }

        );      );          status: 'conflict',

      }

          currentMaster: {

      // Register new master player

      const player = await databases.createDocument(      if (existing.documents.length > 0) {            deviceId: currentMaster.deviceId,

        process.env.APPWRITE_DATABASE_ID,

        'players',        const current = existing.documents[0];            lastHeartbeat: currentMaster.lastHeartbeat,

        'unique()',

        {          },

          playerId: `player_${Date.now()}`,

          venueId,        // Same device? Reconnect        };

          deviceId,

          userAgent,        if (current.deviceId === deviceId) {      }

          status: 'active',

          lastHeartbeat: now,          await databases.updateDocument(

          expiresAt: now + 2 * 60 * 1000, // 2 minutes

          createdAt: new Date().toISOString()            process.env.APPWRITE_DATABASE_ID,      // Expire old master

        }

      );            'players',      await databases.updateDocument(



      log(`New master registered: ${deviceId}`);            current.$id,        process.env.APPWRITE_DATABASE_ID,

      return res.json({

        success: true,            {        'players',

        isMaster: true,

        playerId: player.$id,              lastHeartbeat: Date.now(),        currentMaster.$id,

        status: 'registered'

      });              expiresAt: Date.now() + 2 * 60 * 1000 // 2 minutes        {

    }

            }          status: 'offline',

    // Action: heartbeat - Update player heartbeat

    if (action === 'heartbeat') {          );          expiresAt: Date.now(),

      if (!venueId || !deviceId) {

        return res.json(        }

          { success: false, error: 'Missing required fields' },

          400          log(`Device reconnected: ${deviceId}`);      );

        );

      }    }



      const players = await databases.listDocuments(          return res.json({

        process.env.APPWRITE_DATABASE_ID,

        'players',            success: true,    // Register new master player

        [

          Query.equal('venueId', [venueId]),            isMaster: true,    const player = await databases.createDocument(

          Query.equal('deviceId', [deviceId]),

          Query.equal('status', ['active'])            playerId: current.$id,      process.env.APPWRITE_DATABASE_ID,

        ]

      );            status: 'reconnected'      'players',



      if (players.documents.length === 0) {          });      'unique()',

        return res.json({

          success: false,        }      {

          error: 'Player not found or not active'

        }, 404);        venueId,

      }

        // Different device and still active? Conflict        deviceId,

      const player = players.documents[0];

      const now = Date.now();        if (current.lastHeartbeat > Date.now() - 2 * 60 * 1000) {        userAgent,



      await databases.updateDocument(          log(`Master conflict: ${current.deviceId} still active`);        status: 'active',

        process.env.APPWRITE_DATABASE_ID,

        'players',        lastHeartbeat: Date.now(),

        player.$id,

        {          return res.json({        expiresAt: Date.now() + 24 * 60 * 60 * 1000,

          lastHeartbeat: now,

          expiresAt: now + 2 * 60 * 1000            success: false,        createdAt: new Date().toISOString(),

        }

      );            isMaster: false,      }



      return res.json({            reason: 'MASTER_ACTIVE',    );

        success: true,

        message: 'Heartbeat updated'            currentMaster: {

      });

    }              deviceId: current.deviceId,    return { status: 'registered', playerId: player.$id };



    // Action: status - Check if venue has master              lastHeartbeat: current.lastHeartbeat  } catch (error) {

    if (action === 'status') {

      if (!venueId) {            }    console.error('Player registration failed:', error);

        return res.json(

          { success: false, error: 'Missing venueId' },          });    throw error;

          400

        );        }  }

      }

};

      const now = Date.now();

      const players = await databases.listDocuments(        // Old master expired, take over

        process.env.APPWRITE_DATABASE_ID,

        'players',        await databases.updateDocument(/**

        [

          Query.equal('venueId', [venueId]),          process.env.APPWRITE_DATABASE_ID, * Handle player heartbeat

          Query.equal('status', ['active']),

          Query.greaterThan('expiresAt', now)          'players', */

        ]

      );          current.$id,exports.handlePlayerHeartbeat = async ({ venueId, deviceId }) => {



      if (players.documents.length > 0) {          { status: 'offline' }  const client = new Client()

        const master = players.documents[0];

        return res.json({        );    .setEndpoint(process.env.APPWRITE_ENDPOINT)

          success: true,

          hasMaster: true,      }    .setProject(process.env.APPWRITE_PROJECT_ID)

          deviceId: master.deviceId,

          lastHeartbeat: master.lastHeartbeat    .setKey(process.env.APPWRITE_API_KEY);

        });

      }      // Register new master



      return res.json({      const newMaster = await databases.createDocument(  const databases = new Databases(client);

        success: true,

        hasMaster: false        process.env.APPWRITE_DATABASE_ID,

      });

    }        'players',  try {



    // Action: release - Release master status        'unique()',    const players = await databases.listDocuments(

    if (action === 'release') {

      if (!venueId || !deviceId) {        {      process.env.APPWRITE_DATABASE_ID,

        return res.json(

          { success: false, error: 'Missing required fields' },          playerId: `player_${Date.now()}`,      'players',

          400

        );          venueId,      [

      }

          deviceId,        Query.equal('venueId', venueId),

      const players = await databases.listDocuments(

        process.env.APPWRITE_DATABASE_ID,          status: 'active',        Query.equal('deviceId', deviceId),

        'players',

        [          lastHeartbeat: Date.now(),        Query.equal('status', 'active'),

          Query.equal('venueId', [venueId]),

          Query.equal('deviceId', [deviceId])          expiresAt: Date.now() + 2 * 60 * 1000,      ]

        ]

      );          userAgent: userAgent || 'Unknown',    );



      if (players.documents.length > 0) {          createdAt: new Date().toISOString()

        await databases.updateDocument(

          process.env.APPWRITE_DATABASE_ID,        }    if (players.documents.length > 0) {

          'players',

          players.documents[0].$id,      );      await databases.updateDocument(

          {

            status: 'offline',        process.env.APPWRITE_DATABASE_ID,

            expiresAt: Date.now()

          }      log(`New master registered: ${newMaster.$id}`);        'players',

        );

      }        players.documents[0].$id,



      return res.json({      return res.json({        {

        success: true,

        message: 'Master status released'        success: true,          lastHeartbeat: Date.now(),

      });

    }        isMaster: true,        }



    // Unknown action        playerId: newMaster.$id,      );

    return res.json(

      { success: false, error: 'Invalid action' },        status: 'registered'      return { status: 'updated' };

      400

    );      });    }



  } catch (err) {    }

    error('Player-registry error: ' + err.message);

    return res.json(    return { status: 'not_found' };

      { success: false, error: err.message },

      500    // Update heartbeat  } catch (error) {

    );

  }    if (action === 'heartbeat') {    console.error('Heartbeat failed:', error);

};

      const { playerId } = body;    throw error;

  }

      await databases.updateDocument(};

        process.env.APPWRITE_DATABASE_ID,

        'players',/**

        playerId, * Cleanup expired players

        { */

          lastHeartbeat: Date.now(),exports.cleanupExpiredPlayers = cleanupExpiredPlayers;

          expiresAt: Date.now() + 2 * 60 * 1000

        }async function cleanupExpiredPlayers(databases) {

      );  try {

    const expiredPlayers = await databases.listDocuments(

      log(`Heartbeat updated: ${playerId}`);      process.env.APPWRITE_DATABASE_ID,

      'players',

      return res.json({      [Query.lessThan('expiresAt', Date.now())]

        success: true,    );

        acknowledged: true

      });    for (const player of expiredPlayers.documents) {

    }      await databases.updateDocument(

        process.env.APPWRITE_DATABASE_ID,

    // Check master status        'players',

    if (action === 'status') {        player.$id,

      const players = await databases.listDocuments(        { status: 'offline' }

        process.env.APPWRITE_DATABASE_ID,      );

        'players',    }

        [

          Query.equal('venueId', venueId),    return { cleaned: expiredPlayers.documents.length };

          Query.equal('status', 'active'),  } catch (error) {

          Query.greaterThan('lastHeartbeat', Date.now() - 2 * 60 * 1000)    console.error('Cleanup failed:', error);

        ]    return { cleaned: 0 };

      );  }

}

      if (players.documents.length > 0) {
        const master = players.documents[0];
        return res.json({
          success: true,
          hasMaster: true,
          masterDeviceId: master.deviceId,
          isMaster: master.deviceId === deviceId
        });
      }

      return res.json({
        success: true,
        hasMaster: false,
        masterDeviceId: null,
        isMaster: false
      });
    }

    // Release master status
    if (action === 'release') {
      const { playerId } = body;

      await databases.updateDocument(
        process.env.APPWRITE_DATABASE_ID,
        'players',
        playerId,
        { status: 'offline' }
      );

      log(`Master released: ${playerId}`);

      return res.json({
        success: true,
        released: true
      });
    }

    return res.json({
      success: false,
      error: 'Invalid action. Use: register, heartbeat, status, release'
    }, 400);

  } catch (err) {
    error(`Player-registry error: ${err.message}`);
    error(err.stack);
    return res.json({
      success: false,
      error: err.message
    }, 500);
  }
};
